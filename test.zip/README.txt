Synthetic archive for static-analysis testing only.
